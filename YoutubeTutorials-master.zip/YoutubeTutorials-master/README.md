Hey there!

I'm Christian, and I make games as a hobby. I also run a youtube channel where I post tutorials every now and then.

This is a repository for the code written in my youtube tutorials. Feel free to use the code to your liking. If you happen to use any of my code in your projects and wanna give me a little nod of credit, it's always appreciated. 

Also consider checking out my youtube channel by clicking the duckling below (and maybe even subscribing):

[![Youtube Channe](https://github.com/ChristianD37/YoutubeTutorials/blob/master/readme%20images/logo.gif)](https://www.youtube.com/channel/UCB2mKxxXPK3X8SJkAc-db3A)

Hope you learn a lot : )
